class ShoppingCart {
    private Object Shopping;

    public ShoppingCart(Object shopping) {
        Shopping = shopping;
    }

    @Test
    public void testAppendFormatted() {
        ShoppingCart.appendFormatted();
        assertEquals();
        ShoppingCart.appendFormatted();
        assertEquals();
        ShoppingCart.appendFormatted();
        assertEquals();


        ShoppingCart.appendFormatted();
        assertEquals();
        ShoppingCart.appendFormatted();
        assertEquals();
    }

    private static void appendFormatted() {
    }

    private void assertEquals() {
    }


    @Test
    public void testCalculateDiscount() {
        System.out.println("calculateDiscount");
        int expResult = 0;
        assertEquals();

    }

}
