package CartItem;
import java.io.Serializable;
    public class CartItem implements Serializable {
        private double unitPrice;
        private int quantity;
        private String name;

        public CartItem(String itemName, int itemQuant, double price) {
            name = itemName;
            quantity = itemQuant;
            unitPrice = price;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }

        public double getUnitPrice() {
            return unitPrice;
        }
    }

