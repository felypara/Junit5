import org.junit.Before;
import org.junit.Test;

public class ShoppingCartTest {


   private AddItem Item;

    @Test
    public void addItem() {
    }
    @Before
    public void createCart(){
        ShoppingCart cart = new ShoppingCart();
    }

    }


