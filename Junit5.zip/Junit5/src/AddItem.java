import java.util.Calendar;

public class AddItem {
    public static Calendar Type;
    private String ShoppingCart;
        private double discountTest;

        public AddItem(String ShoppingCart, float test, AddItem _type, double discountTest){
            this.ShoppingCart =ShoppingCart;
            this.discountTest =discountTest;
        }

        public String getShoppingCart() {
            return ShoppingCart;
        }

        public void setShoppingCart(String shoppingCart) {
            this.ShoppingCart = shoppingCart;
        }

        public double getDiscountTest() {
            return discountTest;
        }

        public void setDiscountTest(double discountTest) {
            this.discountTest = discountTest;
        }

    public void AddItemTest(String title, float v, int i, Object regular) {
    }
}




