import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

public class AddItemTest {

    private Object REGULAR;

    @Test
    public void getShoppingCart() {

        AddItemTest cart = new AddItemTest();
    }


    @RunWith(Parameterized.class)
    public static class discountTest {
        private static Object[] Q_VALUES;

        public static Object[] getqValues() {
            return Q_VALUES;
        }

        public static void setqValues(Object[] qValues) {
            Q_VALUES = qValues;
        }
    }
    @SuppressWarnings("ResultOfMethodCallIgnored")
    @Test(expected = IllegalArgumentException.class)
    public void zeroPrice(AddItem cart)

    {
        cart.AddItemTest("Title", 0.00f, 1, REGULAR);
    }


    private static class REGULAR {
    }
}







