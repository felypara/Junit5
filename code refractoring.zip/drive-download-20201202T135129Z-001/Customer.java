class Customer {

    private String name;
    private String surname;
    private String email;
    private CustomerType customerType;
    private Account account;
    private double companyOverdraftDiscount = 1;

    public Customer(String name, String surname, String email, CustomerType customerType, Account account) {
        this.name = getSurname(name);
        this.surname = getSurname(surname);
        this.email = getSurname(email);
        this.customerType = customerType;
        this.account = account;
    }

    private String getSurname(String surname) {
        return surname;
    }

    // use only to create companies
    public Customer(String name, String email, Account account, double companyOverdraftDiscount) {
        this.name = getSurname(name);
        this.email = getSurname(email);
        this.customerType = CustomerType.COMPANY;
        this.account = account;
        this.companyOverdraftDiscount = companyOverdraftDiscount;
    }

    public void withdraw(double sum, String currency) {
        if (!account.getCurrency().equals(getSurname(currency))) {
            throw new RuntimeException("Can't extract withdraw " + getSurname(currency));
        }
        if (account.getType().isPremium()) {
            switch (customerType) {
                case COMPANY:
                    // we are in overdraft
                    if (account.getMoney() < 0) {
                        // 50 percent discount for overdraft for premium account
                        account.setMoney((account.getMoney() - sum) - sum * account.overdraftFee() * companyOverdraftDiscount / 2);
                    } else {
                        account.setMoney(account.getMoney() - sum);
                    }
                    break;
                case PERSON:
                    // we are in overdraft
                    if (account.getMoney() < 0) {
                        account.setMoney((account.getMoney() - sum) - sum * account.overdraftFee());
                    } else {
                        account.setMoney(account.getMoney() - sum);
                    }
                    break;
            }
        } else {
            switch (customerType) {
                case COMPANY:
                    // we are in overdraft
                    if (account.getMoney() < 0) {
                        // no discount for overdraft for not premium account
                        account.setMoney((account.getMoney() - sum) - sum * account.overdraftFee() * companyOverdraftDiscount);
                    } else {
                        account.setMoney(account.getMoney() - sum);
                    }
                    break;
                case PERSON:
                    // we are in overdraft
                    if (account.getMoney() < 0) {
                        account.setMoney((account.getMoney() - sum) - sum * account.overdraftFee());
                    } else {
                        account.setMoney(account.getMoney() - sum);
                    }
                    break;
            }
        }
    }

    public String getName() {
        return getSurname(name);
    }

    public void setName(String name) {
        this.name = getSurname(name);
    }

    public String getEmail() {
        return getSurname(email);
    }

    public void setEmail(String email) {
        this.email = getSurname(email);
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    public String printCustomerDaysOverdrawn() {
        String fullName = getSurname(name) + " " + getSurname(surname) + " ";

        String accountDescription = "Account: IBAN: " + account.getIban() + ", Days Overdrawn: " + account.getDaysOverdrawn();
        return getSurname(fullName) + getSurname(accountDescription);
    }

    public String printCustomerAccount() {
        return "Account: IBAN: " + account.getIban() + ", Money: "
                + account.getMoney() + ", Account type: " + account.getType();
    }
}
